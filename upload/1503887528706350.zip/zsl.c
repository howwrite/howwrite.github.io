#include<stdio.h>
#include<windows.h>
#include<conio.h>
#include<time.h>
#include<stdlib.h>
#define MAX 25//�߽糤�� 
struct se{
	int x;
	int y;
	struct se *next;
	int z;
};
char co[9]={"color f0"};
void gotoxy(int x,int y)
{
    COORD point;
    HANDLE hout;
    point.X = x;
    point.Y = y;
    hout = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleCursorPosition(hout,point);
}
void buju()//��������εĳ���
{
	int i,j;
	for(i=0;i<MAX;i++){
	for(j=0;j<MAX*2;j++)
	{
		if(i==0||i==MAX-1)
		putchar('-');
		else if(j==0||j==MAX*2-1)
		putchar('|');
		else
		putchar(' ');
	}
	printf("\n");
	}
	printf("\t\t\t\t\t\tby XWM 2.5");
 } 
 struct se *chushi(struct se *head)
 {
 	struct se *p,*tail;
 	head=tail=NULL;
 	int i;
 	for(i=0;i<3;i++)
 	{
 		p=(struct se*)malloc(sizeof(struct se));
 		p->next=NULL;
 		p->x=MAX-1+i;
 		p->y=MAX/2;
 		p->z=0;
 		if(head==NULL)
 		{
 			head=p;
 			head->z=1;
		 }
		 else
		 tail->next=p;
		 tail=p;
	 }
	 return head;
 }
 void duqu(struct se *head)
 {
 	struct se *p;
 	char c;
 	for(p=head;p!=NULL;p=p->next)
 	{
 		if(p->z)
 		c='@';
 		else
 		c='*';
 		gotoxy(p->x,p->y);
 		putchar(c);
	 }
 }
 void caozuo(struct se *head,int n,struct se *last)
 {
 	struct se *p;
 	gotoxy(head->x,head->y);
 	putchar('*');
 	gotoxy(last->x,last->y);
 	putchar(' ');
 	int X,Y,x,y;
	X=head->x;
	Y=head->y;
 	for(p=head->next;p!=NULL;p=p->next)
 	{
 		x=p->x;
 		y=p->y;
 		p->x=X;
 		p->y=Y;
 		X=x;
 		Y=y;
	 }
	 if(n==1)
	 head->y--;
	 if(n==2)
	 head->x++;
	 if(n==3)
	 head->y++;
	 if(n==4)
	 head->x--;
	 gotoxy(head->x,head->y);
	 putchar('@');
	 
 }
 void shiwu(int *x,int *y,struct se *p)
 {
 	struct se *p1;
 	int s;
 	do{
 		s=0;
 	srand(time(0));
 	*y=rand()*10%23+2;
 	*x=rand()*10%48+1;
 	for(p1=p;p1!=NULL;p1=p1->next)
 	if(*x==p1->x&&*y==p1->y)
 	s=1;
	 }while(s);
 	gotoxy(*x,*y);
 	putchar('#');
 }
 int jiancha(struct se *head)
 {
 	if(head->x==0||head->x==MAX*2-1||head->y==1||head->y==MAX)
 	return 1;
 	struct se *p;
 	for(p=head->next;p!=NULL;p=p->next)
 	if(p->x==head->x&&p->y==head->y)
 	return 2;
 	return 0;
 	
 }
